"""Reactive state container for the TUI.

Holds all data the UI needs: pipeline phase, tasks, agent output, costs.
Widgets read from this; EventBus writes to this via apply_event().
"""

from __future__ import annotations

import logging
from collections import defaultdict
from collections.abc import Callable

logger = logging.getLogger("forge.tui.state")


class TuiState:
    """Single source of truth for TUI data."""

    def __init__(self, max_output_lines: int = 1000) -> None:
        self._max_output_lines = max_output_lines
        self._change_callbacks: list[Callable[[str], None]] = []

        self.pipeline_id: str | None = None
        self.phase: str = "idle"
        self.total_cost_usd: float = 0.0
        self.elapsed_seconds: float = 0.0

        self.tasks: dict[str, dict] = {}
        self.task_order: list[str] = []
        self.selected_task_id: str | None = None

        self.agent_output: dict[str, list[str]] = defaultdict(list)
        self.planner_output: list[str] = []
        self.error: str | None = None
        self._pending_state_updates: dict[str, dict] = {}

        self.pending_questions: dict[str, dict] = {}  # task_id → question data
        self.review_gates: dict[str, dict[str, dict]] = {}  # task_id → gate_name → {status, details}
        self.pr_url: str | None = None
        self.question_history: dict[str, list[dict]] = {}  # task_id → [Q&A pairs]
        self.review_output: dict[str, list[str]] = defaultdict(list)  # task_id → streaming LLM review lines
        self.streaming_task_ids: set[str] = set()  # tasks currently emitting streaming output
        self.pipeline_branch: str = ""  # branch where task work is merged

        # Feature 2/3/5: contracts, cost, budget, preflight, followup
        self.contracts_output: list[str] = []
        self.contracts_ready: bool = False
        self.contracts_failed: str | None = None
        self.cost_estimate: dict | None = None
        self.budget_exceeded: bool = False
        self.preflight_error: str | None = None
        self.followup_tasks: dict[str, dict] = {}
        self.followup_output: dict[str, list[str]] = defaultdict(list)

    def on_change(self, callback: Callable[[str], None]) -> None:
        self._change_callbacks.append(callback)

    def _notify(self, field: str) -> None:
        for cb in self._change_callbacks:
            try:
                cb(field)
            except Exception:
                logger.exception("Change callback error for field %r", field)

    def apply_event(self, event_type: str, data: dict) -> None:
        handler = self._EVENT_MAP.get(event_type)
        if handler:
            handler(self, data)

    def _on_phase_changed(self, data: dict) -> None:
        self.phase = data.get("phase", self.phase)
        self._notify("phase")

    def _on_plan_ready(self, data: dict) -> None:
        self.tasks.clear()
        self.task_order.clear()
        for t in data.get("tasks", []):
            tid = t["id"]
            self.tasks[tid] = {
                "id": tid,
                "title": t.get("title", ""),
                "description": t.get("description", ""),
                "files": t.get("files", []),
                "depends_on": t.get("depends_on", []),
                "complexity": t.get("complexity", "medium"),
                "state": "todo",
                "agent_cost": 0.0,
                "error": None,
            }
            self.task_order.append(tid)
        if self.task_order:
            # Always reset — IDs may change after daemon remaps them
            self.selected_task_id = self.task_order[0]
        # Apply any buffered state updates that arrived before plan_ready
        for tid, update_data in self._pending_state_updates.items():
            if tid in self.tasks:
                self.tasks[tid]["state"] = update_data.get("state", self.tasks[tid]["state"])
                if "error" in update_data:
                    self.tasks[tid]["error"] = update_data["error"]
        self._pending_state_updates.clear()
        self._notify("tasks")

    def _on_task_state_changed(self, data: dict) -> None:
        tid = data.get("task_id")
        if not tid:
            return
        new_state = data.get("state", "")
        if new_state in ("done", "error"):
            self.streaming_task_ids.discard(tid)
        if tid in self.tasks:
            self.tasks[tid]["state"] = data.get("state", self.tasks[tid]["state"])
            if "error" in data:
                self.tasks[tid]["error"] = data["error"]
            self._notify("tasks")
        else:
            # Buffer for when task is added via plan_ready
            self._pending_state_updates[tid] = data

    def _on_agent_output(self, data: dict) -> None:
        tid = data.get("task_id", "")
        line = data.get("line", "")
        lines = self.agent_output[tid]
        lines.append(line)
        if len(lines) > self._max_output_lines:
            del lines[: len(lines) - self._max_output_lines]
        if tid:
            self.streaming_task_ids.add(tid)
        self._notify("agent_output")

    def _on_planner_output(self, data: dict) -> None:
        self.planner_output.append(data.get("line", ""))
        if len(self.planner_output) > self._max_output_lines:
            del self.planner_output[: len(self.planner_output) - self._max_output_lines]
        self._notify("planner_output")

    def _on_cost_update(self, data: dict) -> None:
        if "total_cost_usd" in data:
            self.total_cost_usd = data["total_cost_usd"]
        self._notify("cost")

    def _on_task_cost_update(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.tasks:
            if "agent_cost" in data:
                self.tasks[tid]["agent_cost"] = data["agent_cost"]
            self._notify("tasks")

    def _on_review_update(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.tasks:
            self.tasks[tid]["review"] = data
            self._notify("tasks")

    def _on_merge_result(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.tasks:
            self.tasks[tid]["merge_result"] = data
            self._notify("tasks")

    def _on_awaiting_approval(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.tasks:
            self.tasks[tid]["state"] = "awaiting_approval"
            self._notify("tasks")

    def _on_pipeline_error(self, data: dict) -> None:
        self.error = data.get("error", "Unknown error")
        self._notify("error")

    def _on_task_question(self, data: dict) -> None:
        task_id = data.get("task_id")
        if task_id and task_id in self.tasks:
            self.tasks[task_id]["state"] = "awaiting_input"
            self.pending_questions[task_id] = data.get("question", {})
            self._notify("tasks")

    def _on_task_answer(self, data: dict) -> None:
        task_id = data.get("task_id")
        if task_id:
            q = self.pending_questions.pop(task_id, None)
            if q:
                history = self.question_history.setdefault(task_id, [])
                history.append({"question": q, "answer": data.get("answer")})
            self._notify("tasks")

    def _on_task_resumed(self, data: dict) -> None:
        task_id = data.get("task_id")
        if task_id and task_id in self.tasks:
            self.tasks[task_id]["state"] = "in_progress"
            self._notify("tasks")

    def _on_task_auto_decided(self, data: dict) -> None:
        task_id = data.get("task_id")
        if task_id:
            q = self.pending_questions.pop(task_id, None)
            if q:
                history = self.question_history.setdefault(task_id, [])
                history.append({"question": q, "answer": f"[auto: {data.get('reason', 'unknown')}]"})
            self._notify("tasks")

    def _on_review_gate_started(self, data: dict) -> None:
        task_id = data.get("task_id")
        gate = data.get("gate")
        if task_id and gate:
            self.review_gates.setdefault(task_id, {})[gate] = {"status": "running"}
            self._notify("tasks")

    def _on_review_gate_passed(self, data: dict) -> None:
        task_id = data.get("task_id")
        gate = data.get("gate")
        if task_id and gate:
            self.review_gates.setdefault(task_id, {})[gate] = {"status": "passed", "details": data.get("details")}
            self._notify("tasks")

    def _on_review_gate_failed(self, data: dict) -> None:
        task_id = data.get("task_id")
        gate = data.get("gate")
        if task_id and gate:
            self.review_gates.setdefault(task_id, {})[gate] = {"status": "failed", "details": data.get("details")}
            self._notify("tasks")

    def _on_review_llm_output(self, data: dict) -> None:
        task_id = data.get("task_id")
        line = data.get("line", "")
        if task_id:
            lines = self.review_output[task_id]
            lines.append(line)
            if len(lines) > self._max_output_lines:
                del lines[: len(lines) - self._max_output_lines]
            self.streaming_task_ids.add(task_id)
            self._notify("review_output")

    def _on_review_llm_feedback(self, data: dict) -> None:
        task_id = data.get("task_id")
        if task_id:
            gates = self.review_gates.setdefault(task_id, {})
            gates["gate2_llm_review"] = {"status": "passed", "details": data.get("feedback")}
            self._notify("tasks")

    def _on_cost_estimate(self, data: dict) -> None:
        self.cost_estimate = data
        self._notify("cost_estimate")

    def _on_budget_exceeded(self, data: dict) -> None:
        self.budget_exceeded = True
        self._notify("budget_exceeded")

    def _on_contracts_output(self, data: dict) -> None:
        self.contracts_output.append(data.get("line", ""))
        if len(self.contracts_output) > self._max_output_lines:
            del self.contracts_output[: len(self.contracts_output) - self._max_output_lines]
        self._notify("contracts_output")

    def _on_contracts_ready(self, data: dict) -> None:
        self.contracts_ready = True
        self._notify("contracts_ready")

    def _on_contracts_failed(self, data: dict) -> None:
        self.contracts_failed = data.get("error", "Unknown")
        self._notify("contracts_failed")

    def _on_files_changed(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.tasks:
            self.tasks[tid]["files_changed"] = data.get("files", [])
            self._notify("tasks")

    def _on_cancelled(self, data: dict) -> None:
        self.phase = "cancelled"
        self._notify("phase")

    def _on_paused(self, data: dict) -> None:
        self.phase = "paused"
        self._notify("phase")

    def _on_pipeline_resumed(self, data: dict) -> None:
        self.phase = "executing"
        self._notify("phase")

    def _on_restarted(self, data: dict) -> None:
        self.tasks.clear()
        self.task_order.clear()
        self.agent_output.clear()
        self.planner_output.clear()
        self.contracts_output.clear()
        self.contracts_ready = False
        self.contracts_failed = None
        self.cost_estimate = None
        self.budget_exceeded = False
        self.preflight_error = None
        self.followup_tasks.clear()
        self.followup_output.clear()
        self.error = None
        self.total_cost_usd = 0.0
        self.phase = "planning"
        self._notify("phase")

    def _on_worktrees_cleaned(self, data: dict) -> None:
        logger.debug("Worktrees cleaned event received")

    def _on_preflight_failed(self, data: dict) -> None:
        self.preflight_error = data.get("error", "Unknown")
        self._notify("preflight_error")

    def _on_followup_started(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid:
            self.followup_tasks[tid] = {"task_id": tid, "state": "started", "error": None}
            self._notify("followup_tasks")

    def _on_followup_completed(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.followup_tasks:
            self.followup_tasks[tid]["state"] = "completed"
            self._notify("followup_tasks")

    def _on_followup_error(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid and tid in self.followup_tasks:
            self.followup_tasks[tid]["state"] = "error"
            self.followup_tasks[tid]["error"] = data.get("error")
            self._notify("followup_tasks")

    def _on_followup_output(self, data: dict) -> None:
        tid = data.get("task_id")
        if tid:
            self.followup_output[tid].append(data.get("line", ""))
            self._notify("followup_output")

    def _on_slot_acquired(self, data: dict) -> None:
        logger.debug("Slot acquired event received")

    def _on_slot_released(self, data: dict) -> None:
        logger.debug("Slot released event received")

    def _on_slot_queued(self, data: dict) -> None:
        logger.debug("Slot queued event received")

    def _on_all_tasks_done(self, data: dict) -> None:
        self.phase = "final_approval"
        self._notify("phase")

    def _on_pr_creating(self, data: dict) -> None:
        self.phase = "pr_creating"
        self._notify("phase")

    def _on_pr_created(self, data: dict) -> None:
        self.pr_url = data.get("pr_url")
        self.phase = "pr_created"
        self._notify("phase")

    def _on_pr_failed(self, data: dict) -> None:
        self.error = data.get("error", "PR creation failed")
        self._notify("error")

    def reset(self) -> None:
        """Reset all pipeline-specific state for a new task."""
        self.phase = "idle"
        self.tasks.clear()
        self.task_order.clear()
        self.selected_task_id = None
        self.agent_output.clear()
        self.review_output.clear()
        self.planner_output.clear()
        self.review_gates.clear()
        self.streaming_task_ids.clear()
        self.error = None
        self.elapsed_seconds = 0.0
        self.total_cost_usd = 0.0
        self.pipeline_branch = ""
        self.question_history.clear()
        self.pending_questions.clear()
        self.pr_url = None
        self._pending_state_updates.clear()

    @property
    def done_count(self) -> int:
        return sum(1 for t in self.tasks.values() if t["state"] == "done")

    @property
    def error_count(self) -> int:
        return sum(1 for t in self.tasks.values() if t["state"] == "error")

    @property
    def total_count(self) -> int:
        return len(self.tasks)

    @property
    def progress_pct(self) -> float:
        if not self.tasks:
            return 0.0
        return (self.done_count / self.total_count) * 100

    @property
    def active_task_ids(self) -> list[str]:
        return [tid for tid, t in self.tasks.items() if t["state"] in ("in_progress", "in_review", "merging")]

    _EVENT_MAP: dict[str, Callable[["TuiState", dict], None]] = {
        "pipeline:phase_changed": _on_phase_changed,
        "pipeline:plan_ready": _on_plan_ready,
        "pipeline:cost_update": _on_cost_update,
        "pipeline:error": _on_pipeline_error,
        "task:state_changed": _on_task_state_changed,
        "task:agent_output": _on_agent_output,
        "task:cost_update": _on_task_cost_update,
        "task:review_update": _on_review_update,
        "task:merge_result": _on_merge_result,
        "task:awaiting_approval": _on_awaiting_approval,
        "planner:output": _on_planner_output,
        "task:question": _on_task_question,
        "task:answer": _on_task_answer,
        "task:resumed": _on_task_resumed,
        "task:auto_decided": _on_task_auto_decided,
        "review:gate_started": _on_review_gate_started,
        "review:gate_passed": _on_review_gate_passed,
        "review:gate_failed": _on_review_gate_failed,
        "review:llm_feedback": _on_review_llm_feedback,
        "review:llm_output": _on_review_llm_output,
        "pipeline:all_tasks_done": _on_all_tasks_done,
        "pipeline:pr_creating": _on_pr_creating,
        "pipeline:pr_created": _on_pr_created,
        "pipeline:pr_failed": _on_pr_failed,
        "pipeline:cost_estimate": _on_cost_estimate,
        "pipeline:budget_exceeded": _on_budget_exceeded,
        "contracts:output": _on_contracts_output,
        "pipeline:contracts_ready": _on_contracts_ready,
        "pipeline:contracts_failed": _on_contracts_failed,
        "task:files_changed": _on_files_changed,
        "pipeline:cancelled": _on_cancelled,
        "pipeline:paused": _on_paused,
        "pipeline:resumed": _on_pipeline_resumed,
        "pipeline:restarted": _on_restarted,
        "pipeline:worktrees_cleaned": _on_worktrees_cleaned,
        "pipeline:preflight_failed": _on_preflight_failed,
        "followup:task_started": _on_followup_started,
        "followup:task_completed": _on_followup_completed,
        "followup:task_error": _on_followup_error,
        "followup:agent_output": _on_followup_output,
        "slot:acquired": _on_slot_acquired,
        "slot:released": _on_slot_released,
        "slot:queued": _on_slot_queued,
    }
