"""Forge TUI widgets."""
