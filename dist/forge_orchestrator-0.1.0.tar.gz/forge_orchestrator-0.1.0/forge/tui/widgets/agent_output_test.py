"""Tests for AgentOutput widget."""

from __future__ import annotations


from forge.tui.widgets.agent_output import (
    AgentOutput,
    _TYPING_FRAMES,
    format_error_detail,
    format_header,
    format_output,
)


# ── format_header tests ──────────────────────────────────────────────────


def test_format_header_with_task():
    header = format_header("task-1", "Auth middleware", "in_progress")
    assert "Auth middleware" in header
    assert "task-1" in header


def test_format_header_no_task():
    header = format_header(None, None, None)
    assert "No task selected" in header


def test_format_header_planner():
    header = format_header("planner", "Planning", "planning")
    assert "Planner" in header
    assert "exploring" in header


# ── format_output tests ─────────────────────────────────────────────────


def test_format_output_empty():
    from forge.tui.widgets.agent_output import _SPINNER_FRAMES
    result = format_output([])
    assert "Waiting" in result
    assert _SPINNER_FRAMES[0] in result


def test_format_output_spinner_frames():
    from forge.tui.widgets.agent_output import _SPINNER_FRAMES
    result_0 = format_output([], spinner_frame=0)
    result_1 = format_output([], spinner_frame=1)
    assert _SPINNER_FRAMES[0] in result_0
    assert _SPINNER_FRAMES[1] in result_1


def test_format_output_with_lines():
    lines = ["Creating auth/jwt.py...", "Adding middleware...", "Done."]
    result = format_output(lines)
    assert "Creating auth/jwt.py..." in result
    assert "Done." in result


def test_format_output_no_typing_indicator_by_default():
    lines = ["line1", "line2"]
    result = format_output(lines)
    assert "Typing" not in result


def test_format_output_with_streaming_shows_typing_indicator():
    lines = ["line1", "line2"]
    result = format_output(lines, streaming=True, typing_frame=0)
    assert "Typing" in result
    cursor = _TYPING_FRAMES[0]
    assert cursor in result


def test_format_output_streaming_false_no_indicator():
    lines = ["line1"]
    result = format_output(lines, streaming=False)
    assert "Typing" not in result


def test_format_output_typing_frame_cycles():
    lines = ["line1"]
    result_0 = format_output(lines, streaming=True, typing_frame=0)
    result_1 = format_output(lines, streaming=True, typing_frame=1)
    # Both should contain the typing indicator
    assert "Typing" in result_0
    assert "Typing" in result_1
    # Cursor chars should differ
    assert _TYPING_FRAMES[0] in result_0
    assert _TYPING_FRAMES[1] in result_1


def test_format_output_empty_lines_no_streaming_indicator():
    """When lines is empty, streaming indicator should NOT appear (spinner shown instead)."""
    result = format_output([], streaming=True, typing_frame=0)
    assert "Waiting" in result


# ── AgentOutput widget unit tests ────────────────────────────────────────


def test_agent_output_init_defaults():
    widget = AgentOutput()
    assert widget._lines == []
    assert widget._streaming is False
    assert widget._typing_frame == 0
    assert widget._typing_timer is None


def test_set_streaming_on_before_compose():
    """set_streaming should not raise when widget is not yet composed."""
    widget = AgentOutput()
    widget.set_streaming(True)
    assert widget._streaming is True


def test_set_streaming_off_before_compose():
    widget = AgentOutput()
    widget.set_streaming(True)
    widget.set_streaming(False)
    assert widget._streaming is False
    assert widget._typing_timer is None
    assert widget._typing_frame == 0


def test_set_streaming_idempotent():
    """Calling set_streaming with the same value should be a no-op."""
    widget = AgentOutput()
    widget.set_streaming(False)  # already False
    assert widget._streaming is False
    assert widget._typing_timer is None


def test_append_line_adds_to_lines():
    widget = AgentOutput()
    widget.append_line("first line")
    assert widget._lines == ["first line"]
    widget.append_line("second line")
    assert widget._lines == ["first line", "second line"]


def test_append_line_before_compose():
    """append_line should not raise before widget is composed."""
    widget = AgentOutput()
    widget.append_line("safe to call")
    assert widget._lines == ["safe to call"]


def test_update_output_resets_streaming():
    """update_output should call set_streaming(False) internally."""
    widget = AgentOutput()
    widget._streaming = True
    widget.update_output("task-1", "Test", "running", ["line1"])
    assert widget._streaming is False
    assert widget._task_id == "task-1"
    assert widget._title == "Test"
    assert widget._state == "running"
    assert widget._lines == ["line1"]


def test_update_output_replaces_lines():
    widget = AgentOutput()
    widget._lines = ["old1", "old2"]
    widget.update_output("t1", "T", "s", ["new1"])
    assert widget._lines == ["new1"]


def test_update_output_before_compose():
    """update_output should not raise before widget is composed."""
    widget = AgentOutput()
    widget.update_output("t1", "Title", "running", ["line"])
    assert widget._lines == ["line"]


def test_tick_typing_increments_frame():
    widget = AgentOutput()
    widget._streaming = True
    widget._typing_frame = 0
    # _tick_typing will fail on query_one but should still increment frame
    widget._tick_typing()
    assert widget._typing_frame == 1


def test_tick_typing_noop_when_not_streaming():
    widget = AgentOutput()
    widget._streaming = False
    widget._typing_frame = 5
    widget._tick_typing()
    assert widget._typing_frame == 5  # unchanged


def test_set_streaming_on_off_resets_typing_frame():
    widget = AgentOutput()
    widget.set_streaming(True)
    widget._typing_frame = 5
    widget.set_streaming(False)
    assert widget._typing_frame == 0


# ── format_error_detail tests ─────────────────────────────────────────


def test_format_error_detail_basic():
    """Error detail view should contain header, error, and action bar."""
    task = {"title": "Auth middleware", "error": "Import failed", "files_changed": ["auth.py"]}
    result = format_error_detail("task-1", task, ["line1", "line2"])
    assert "✖ Auth middleware — ERROR" in result
    assert "Import failed" in result
    assert "auth.py" in result
    assert "Last output" in result
    assert "line1" in result
    assert "line2" in result
    assert "[r] retry" in result
    assert "[s] skip" in result
    assert "[Esc] dismiss" in result


def test_format_error_detail_no_files_changed():
    """Error detail without files_changed should still render."""
    task = {"title": "Task X", "error": "Boom"}
    result = format_error_detail("task-1", task, [])
    assert "✖ Task X — ERROR" in result
    assert "Boom" in result
    assert "No output captured" in result


def test_format_error_detail_truncates_to_last_20_lines():
    """Only the last 20 lines of output should be shown."""
    lines = [f"line-{i}" for i in range(50)]
    task = {"title": "T", "error": "err"}
    result = format_error_detail("t1", task, lines)
    assert "line-30" in result
    assert "line-49" in result
    assert "line-0" not in result


def test_format_error_detail_fewer_than_20_lines():
    """When fewer than 20 lines, all should be shown."""
    lines = [f"line-{i}" for i in range(5)]
    task = {"title": "T", "error": "err"}
    result = format_error_detail("t1", task, lines)
    for i in range(5):
        assert f"line-{i}" in result


def test_format_error_detail_default_error_message():
    """When error key is missing, should show 'Unknown error'."""
    task = {"title": "T"}
    result = format_error_detail("t1", task, [])
    assert "Unknown error" in result


def test_format_error_detail_valid_rich_markup():
    """Error detail output should be valid Rich markup."""
    from rich.console import Console
    from io import StringIO

    task = {"title": "Auth", "error": "Failed", "files_changed": ["a.py"]}
    result = format_error_detail("t1", task, ["line1"])
    console = Console(file=StringIO(), force_terminal=True)
    console.print(result)  # Raises MarkupError if broken


# ── AgentOutput error mode tests ──────────────────────────────────────


def test_agent_output_error_mode_default_false():
    widget = AgentOutput()
    assert widget.is_error_mode is False


def test_agent_output_render_error_detail_sets_mode():
    widget = AgentOutput()
    task = {"title": "T", "error": "err"}
    widget.render_error_detail("t1", task, ["line"])
    assert widget.is_error_mode is True
    assert widget._streaming is False


def test_agent_output_clear_error_detail_resets_mode():
    widget = AgentOutput()
    task = {"title": "T", "error": "err"}
    widget.render_error_detail("t1", task, ["line"])
    widget.clear_error_detail()
    assert widget.is_error_mode is False


def test_agent_output_render_error_detail_before_compose():
    """render_error_detail should not raise before widget is composed."""
    widget = AgentOutput()
    task = {"title": "T", "error": "err", "files_changed": ["a.py"]}
    widget.render_error_detail("t1", task, ["line1", "line2"])
    assert widget.is_error_mode is True
    assert widget._task_id == "t1"
